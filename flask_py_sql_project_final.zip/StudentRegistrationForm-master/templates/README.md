# Simple Registration form using python flask, sqlite3 and html

